// Created by iWeb 3.0 local-build-20090220

setTransparentGifURL('Media/transparent.gif');function applyEffects()
{var registry=IWCreateEffectRegistry();registry.registerEffects({stroke_0:new IWStrokeParts([{rect:new IWRect(-1,1,2,198),url:'Mecanismes_files/stroke.png'},{rect:new IWRect(-1,-1,2,2),url:'Mecanismes_files/stroke_1.png'},{rect:new IWRect(1,-1,106,2),url:'Mecanismes_files/stroke_2.png'},{rect:new IWRect(107,-1,3,2),url:'Mecanismes_files/stroke_3.png'},{rect:new IWRect(107,1,3,198),url:'Mecanismes_files/stroke_4.png'},{rect:new IWRect(107,199,3,2),url:'Mecanismes_files/stroke_5.png'},{rect:new IWRect(1,199,106,2),url:'Mecanismes_files/stroke_6.png'},{rect:new IWRect(-1,199,2,2),url:'Mecanismes_files/stroke_7.png'}],new IWSize(108,200)),shadow_2:new IWShadow({blurRadius:4,offset:new IWPoint(1.4142,1.4142),color:'#000000',opacity:0.500000}),shadow_3:new IWShadow({blurRadius:4,offset:new IWPoint(1.4142,1.4142),color:'#000000',opacity:0.500000}),shadow_0:new IWShadow({blurRadius:10,offset:new IWPoint(4.2426,4.2426),color:'#000000',opacity:0.750000}),reflection_0:new IWReflection({opacity:0.50,offset:1.00}),shadow_1:new IWShadow({blurRadius:4,offset:new IWPoint(1.4142,1.4142),color:'#000000',opacity:0.500000})});registry.applyEffects();}
function hostedOnDM()
{return false;}
function onPageLoad()
{loadMozillaCSS('Mecanismes_files/MecanismesMoz.css')
adjustLineHeightIfTooBig('id1');adjustFontSizeIfTooBig('id1');adjustLineHeightIfTooBig('id2');adjustFontSizeIfTooBig('id2');adjustLineHeightIfTooBig('id3');adjustFontSizeIfTooBig('id3');detectBrowser();adjustLineHeightIfTooBig('id4');adjustFontSizeIfTooBig('id4');adjustLineHeightIfTooBig('id5');adjustFontSizeIfTooBig('id5');adjustLineHeightIfTooBig('id6');adjustFontSizeIfTooBig('id6');adjustLineHeightIfTooBig('id7');adjustFontSizeIfTooBig('id7');adjustLineHeightIfTooBig('id8');adjustFontSizeIfTooBig('id8');adjustLineHeightIfTooBig('id9');adjustFontSizeIfTooBig('id9');Widget.onload();fixAllIEPNGs('Media/transparent.gif');fixupAllIEPNGBGs();applyEffects()}
function onPageUnload()
{Widget.onunload();}
